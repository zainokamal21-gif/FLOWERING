# FLOWERING
**Where connections bloom.**

This is a functional offline-first browser app bundle with local profile, contact list, chats and message persistence, local attachment previews (2 MB limit), story text publishing/viewing, search, theme settings, and PWA caching.

## Use on Android
1. Extract this folder.
2. Open `index.html` in a modern browser to use it locally (some install/offline features require hosting over HTTPS or localhost).
3. For the PWA install experience, publish the folder to a static HTTPS host and use the browser's **Add to Home Screen** option.

## Data & limits
Data is stored locally in browser `localStorage`; it does not sync across devices or users. This bundle does **not** provide online messaging, real Google sign-in, remote contacts, cloud media storage, push notifications, end-to-end encryption or voice/video calls. Those features require backend infrastructure, credentials, and security work. Do not use this local version for sensitive information.
